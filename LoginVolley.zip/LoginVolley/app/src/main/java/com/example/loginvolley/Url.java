package com.example.loginvolley;

public class Url {
    private static final String ROOT_URL = "http://192.168.1.35/androidphpmysql/registrationapi.php?apicall=";
    public static final String URL_REGISTER = ROOT_URL + "registration";
    public static final String URL_LOGIN= ROOT_URL + "login";
    public static final String URL_DOCTOR= ROOT_URL + "doctor";
}

package com.example.loginvolley;

public class User {
    private int id;
    private String name, number, specalization, location;

    public  User( int id, String name, String number, String specalization, String location ) {
        this.id = id;
        this.number = number;
        this.specalization = specalization;
        this.location = location;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }


    public String getSpecalization() {
        return specalization;
    }

    public void setSpecalization(String specalization) {
        this.specalization = specalization;
    }
    public String getLocation() {
        return specalization;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
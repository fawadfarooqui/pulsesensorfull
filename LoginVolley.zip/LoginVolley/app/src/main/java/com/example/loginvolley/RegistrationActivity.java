package com.example.loginvolley;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;


import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

import android.os.Bundle;

public class RegistrationActivity extends AppCompatActivity {
    public class RegistertrActivity extends AppCompatActivity {
        EditText editTextPatientname, editTextNumber, editTextPassword, editTextDoctorName, editTextDoctorNumber, editTextContactPersonNumber;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_registration);

            //if the user is already logged in we will directly start the MainActivity (profile) activity
            if (SharedPrefManager.getInstance(this).isLoggedIn()) {
                finish();
                startActivity(new Intent(this, MainActivity.class));
                return;
            }
            editTextPatientname = findViewById(R.id.editTextPatientname);
            editTextNumber = findViewById(R.id.editTextNumber);
            editTextPassword = findViewById(R.id.editTextPassword);
            editTextDoctorName = findViewById(R.id.editTextDoctorName);
            editTextDoctorNumber = findViewById(R.id.editTextDoctorNumber);
            editTextContactPersonNumber = findViewById(R.id.editTextContactPersonNumber);
            findViewById(R.id.Register_button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //if user pressed on button register
                    //here we will register the user to server
                    registerUser();
                }
            });
            findViewById(R.id.textViewLogin).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //if user pressed on textview that already register open LoginActivity
                    finish();
                    startActivity(new Intent(RegistrationActivity.this, LoginActivity.class));
                }
            });

        }

        private void registerUser() {
            final String pateintname = editTextPatientname.getText().toString().trim();
            final String number = editTextNumber.getText().toString().trim();
            final String password = editTextPassword.getText().toString().trim();
            final String doctorname = editTextDoctorName.getText().toString().trim();
            final String doctornumber = editTextDoctorNumber.getText().toString().trim();
            final String relitivrnumber = editTextContactPersonNumber.getText().toString().trim();

            //first we will do the validations
            if (TextUtils.isEmpty(pateintname)) {
                editTextPatientname.setError("Please enter patientname");
                editTextPatientname.requestFocus();
                return;
            }

            if (TextUtils.isEmpty(number)) {
                editTextNumber.setError("Please enter your patientNumbr");
                editTextNumber.requestFocus();
                return;
            }

            if (TextUtils.isEmpty(password)) {
                editTextPassword.setError("Enter a password");
                editTextPassword.requestFocus();
                return;
            }

            if (TextUtils.isEmpty(doctorname)) {
                editTextDoctorName.setError("Please enter doctortname");
                editTextPatientname.requestFocus();
                return;
            }

            if (TextUtils.isEmpty(doctornumber)) {
                editTextDoctorNumber.setError("Please enter your doctorNumbr");
                editTextDoctorNumber.requestFocus();
                return;
            }

            if (TextUtils.isEmpty(relitivrnumber)) {
                editTextContactPersonNumber.setError("Enter a relitivrnumber");
                editTextContactPersonNumber.requestFocus();
                return;
            }

            StringRequest stringRequest = new StringRequest(Request.Method.POST, Url.URL_REGISTER,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {


                            try {
                                //converting response to json object
                                JSONObject obj = new JSONObject(response);
                                //if no error in response
                                if (!obj.getBoolean("error")) {
                                    Toast.makeText(getApplicationContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();

                                    //getting the user from the response
                                    JSONObject userJson = obj.getJSONObject("user");

                                    //creating a new user object
                                    User user = new User(
                                            userJson.getInt("id"),
                                            userJson.getString("number"),
                                            userJson.getString("specalization"),
                                            userJson.getString("location"),
                                            userJson.getString("name")
                                    );

                                    //storing the user in shared preferences
                                    SharedPrefManager.getInstance(getApplicationContext()).userLogin(user);

                                    //starting the profile activity
                                    finish();
                                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                                } else {
                                    Toast.makeText(getApplicationContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
            {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    params.put("username", pateintname);
                    params.put("number", number);
                    params.put("password", password);
                    params.put("doctorname", doctorname);
                    params.put("doctornumber", doctornumber);
                    params.put("relitivename", relitivrnumber);

                    return params;
                }
            };

            VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
        }

    }

    }

